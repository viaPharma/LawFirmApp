// attorneys-list.component.ts
import { Component, OnInit } from '@angular/core';
import { AttorneyService } from '../../services/attorney.service';

@Component({
  selector: 'app-attorneys-list',
  templateUrl: './attorneys-list.component.html',
  styleUrls: ['./attorneys-list.component.less'] // Using Less
})
export class AttorneysListComponent implements OnInit {
  attorneys = [{name: "", email: "", phoneNumber: ""}];

  constructor(private attorneyService: AttorneyService) {}

  ngOnInit() {
    this.attorneyService.getAttorneys().subscribe(data => {
      this.attorneys = data;
    });
  }
}
