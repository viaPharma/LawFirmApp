import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AttorneyService } from '../../services/attorney.service';

@Component({
  selector: 'app-attorney-form',
  templateUrl: './attorney-form.component.html',
  styleUrls: ['./attorney-form.component.less'] // Using Less
})
export class AttorneyFormComponent {
  attorney = { name: '', email: '', phoneNumber: '' };

  constructor(private attorneyService: AttorneyService, private router: Router) {}

  addAttorney() {
    this.attorneyService.addAttorney(this.attorney).subscribe(() => {
      this.router.navigate(['/attorneys']); // Navigate back to list after adding
    });
  }
}
